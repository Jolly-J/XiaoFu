# 声屿 · 原生 Android 视频音频工具

独立原创 Kotlin / Jetpack Compose 应用。Android 8.0（API 26）及以上。

## 工作流（1.0.2）

- **转音频**：首页只负责选择视频、提取 M4A 或 WAV、播放和另存。不自动进入转写、不自动上传。
- **历史**：仅成功导出的音频进入历史；需要文字时，点击该文件的“转为文字 · MiniMax”，确认上传后才识别。
- **设置**：选择浅色、深色或跟随系统（跨重启保留），配置、替换或删除自己的 MiniMax API Key。

**本地提取不联网、不上传视频。只有用户主动确认的转写会把音频发送给 MiniMax。** API Key 使用 Android Keystore 加密保存在不备份目录；没有内置 Key，不写入日志。MiniMax 调用可能计费。音频库在应用私有目录，卸载将删除，请另存重要文件。

### 1.0.2 修复与诊断

修复有效负音频时间戳（包括恰好 `-1µs`）被误判为空音轨的问题。结束状态只根据真实轨道/读取结果判断，AAC 原样封装保留全部可读包；真正加密内容仍不支持。保留 1.0.1 对 EOF 加密误报和限定 API28 AAC 元数据异常的修复。

设置与提取失败卡片提供“复制诊断信息”：仅最近三次内存中的白名单技术数据，不含 Key、URI、路径、文件名或媒体内容，不自动上传。详见 `docs/NEGATIVE-PTS-1.0.2.md`。

APK 与旧版同签名、版本号递增，可覆盖安装保留现有本地数据，无需卸载。具体设备测试结果和未覆盖项以 `TEST_REPORT.md` 为准，不能据此承诺所有手机或原视频均已验证。

## 格式边界

- MP4 是容器；H.264/H.265/HEVC 是视频编码。提取只读取音轨，不需要解码视频画面。
- 常用 MP4/MOV/WebM/MKV 等容器的可读性取决于 Android MediaExtractor 和设备能力，不承诺所有格式或所有编码组合。
- AAC → M4A 不重编码；其他可解码音轨 → AAC-LC，单声道 128 kbps / 立体声 192 kbps。转码会损失质量。
- WAV：PCM16，保留源采样率，支持单/双声道，传统 RIFF 上限约 4 GiB。
- DRM/加密内容、损坏文件、无音轨、设备不支持的编码会明确报错。首版不提供 MP3 编码，不虚报 MP3 支持。
- 已实测限制：Android 9/API28 的系统提取器不支持 MP3 音轨封装在 MP4/3GPP 中；同一素材在 API35 可转。此组合在旧平台会报告无可读取音轨，不等于原文件实际无音轨。
- 首版选择第一条音轨；不提供多音轨选择、剪辑或批处理。

## 构建

JDK 17+（需完整 JDK，不是 JRE）、Android SDK 35 / Build Tools 35.0.0。

```sh
# Android Studio 打开本目录；或设置 ANDROID_HOME、JAVA_HOME 后：
./gradlew assembleDebug testDebugUnitTest lintDebug assembleDebugAndroidTest
# 源码交付不包含测试视频；先准备fixture（需FFmpeg/curl）：
./scripts/prepare-test-media.sh
./compatibility-tests/prepare-media.sh
# 有连接设备或模拟器时：
./gradlew connectedDebugAndroidTest
```

版本固定在 Gradle 配置中。Debug APK 自签名，可侧载安装，仅供个人试用；不代表已发布商店或经过生产审核。不要把调试签名用于正式公开分发。

## 设计与架构

- Compose Material 3，原创克制圆角、细边、柔阴影，支持深浅色。
- `AudioEngine`：MediaExtractor / MediaMuxer / MediaCodec；逐包/逐帧真实进度、协程取消与失败清理。
- `AudioViewModel`：保留旋转期间任务和状态；本地导出列表从磁盘恢复。
- `TranscriptionEngine` / `ApiKeyStore`：分段网络转写与加密凭据。
- 官方 Android 返回回调，返回取消手势不会误导航；系统支持时可预测返回到桌面。
- 不使用 WebView，不拷贝第三方商业 APK、品牌或源代码，不内置分析/广告 SDK。

## 运行限制

提取/转写为前台交互工作流，没有后台常驻服务；长任务请保持应用打开。系统回收进程会中断当前任务；已成功导出的音频保留，转写成功片段会缓存用于重试。真实设备的编解码能力、厂商文件提供器及 MiniMax 账户权限仍需按具体设备验证；模拟器矩阵和合成长素材不能替代用户原文件实测。

## 官方参考

- https://developer.android.com/reference/android/media/MediaExtractor
- https://developer.android.com/reference/android/media/MediaMuxer
- https://developer.android.com/reference/android/media/MediaCodec
- https://developer.android.com/guide/navigation/custom-back/predictive-back-gesture
- https://solutions.minimaxi.com/debug/asr

测试状态见 `TEST_REPORT.md`。没有 API Key，因此不进行真实付费转写调用。

取消云端转写不能撤回已经上传的内容，也不保证取消计费。删除音频库条目会同时删除关联的本地转写文字与分段缓存，已另存副本不受影响。
