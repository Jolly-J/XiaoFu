package dev.local.audio

import android.content.ClipData
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.PredictiveBackHandler
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.CancellationException
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AudioApp() }
    }
}
private val Light = lightColorScheme(primary=Color(0xFF245D49), onPrimary=Color.White, background=Color(0xFFF6F7F4), surface=Color.White, onSurface=Color(0xFF202622), surfaceVariant=Color(0xFFE9EEE8), onSurfaceVariant=Color(0xFF646E67), outlineVariant=Color(0xFFE1E6E0))
private val Dark = darkColorScheme(primary=Color(0xFFB7DCC6), onPrimary=Color(0xFF183B2E), background=Color(0xFF181B19), surface=Color(0xFF242925), onSurface=Color(0xFFE8ECE6), surfaceVariant=Color(0xFF303831), onSurfaceVariant=Color(0xFFABB6AD), outlineVariant=Color(0xFF414A42))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioApp(vm: AudioViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var transcriptionFile by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val page = selectedTab == 1
    val context = LocalContext.current
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    val preferences = remember(context) { context.getSharedPreferences("appearance", android.content.Context.MODE_PRIVATE) }
    var themeMode by remember { mutableIntStateOf(preferences.getInt("theme_mode", 0)) }
    val dark = when(themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val tabScrollStates = List(3) { rememberScrollState() }
    SideEffect {
        (context as? android.app.Activity)?.window?.let { window ->
            androidx.core.view.WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    var backProgress by remember { mutableFloatStateOf(0f) }
    val snackbar = remember { SnackbarHostState() }
    var saveFile by rememberSaveable { mutableStateOf<String?>(null) }
    var deleteFile by remember { mutableStateOf<File?>(null) }
    var playing by remember { mutableStateOf<File?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    fun stop() { player?.release(); player = null; playing = null }
    DisposableEffect(Unit) { onDispose { player?.release() } }
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event -> if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) stop() }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            stop(); vm.select(uri)
        }
    }
    val saver = rememberLauncherForActivityResult(object : ActivityResultContracts.CreateDocument("audio/mp4") { override fun createIntent(context: android.content.Context, input: String): Intent = super.createIntent(context, input).setType(if(input.endsWith(".wav")) "audio/wav" else "audio/mp4") }) { uri ->
        val file = saveFile?.let(::File)
        if (uri != null && file != null) vm.save(file, uri)
        saveFile = null
    }
    fun save(file: File) { saveFile = file.absolutePath; saver.launch(file.name) }
    fun share(file: File) {
        runCatching {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = if(file.extension=="wav") "audio/wav" else "audio/mp4"; putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("音频", uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "分享音频"))
        }.onFailure { vm.message("当前没有可用的分享应用。") }
    }
    fun play(file: File) {
        if (playing == file) { stop(); return }
        stop()
        runCatching {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { it.start(); playing = file }
                setOnCompletionListener { stop() }
                setOnErrorListener { _, _, _ -> stop(); vm.message("无法播放此音频。"); true }
                prepareAsync()
            }
        }.onFailure { stop(); vm.message("无法播放此音频。") }
    }
    LaunchedEffect(state.message) { state.message?.let { snackbar.showSnackbar(it); vm.clearMessage() } }
    PredictiveBackHandler(enabled = selectedTab != 0 && transcriptionFile == null) { events ->
        try { events.collect { backProgress = it.progress }; selectedTab = 0 }
        catch (_: CancellationException) { /* A cancelled gesture must leave navigation unchanged. */ }
        finally { backProgress = 0f }
    }
    MaterialTheme(colorScheme = if (dark) Dark else Light) {
        if (transcriptionFile != null) {
            TranscriptionScreen(File(transcriptionFile!!), onBack = { transcriptionFile = null })
            return@MaterialTheme
        }
        Scaffold(containerColor = MaterialTheme.colorScheme.background, snackbarHost = { SnackbarHost(snackbar) }, bottomBar = {
            NavigationBar {
                NavigationBarItem(selected=selectedTab==0,onClick={selectedTab=0},icon={Icon(Icons.Outlined.AudioFile,null)},label={Text("转音频")})
                NavigationBarItem(selected=selectedTab==1,onClick={selectedTab=1},icon={Icon(Icons.Outlined.History,null)},label={Text("历史")})
                NavigationBarItem(selected=selectedTab==2,onClick={selectedTab=2},icon={Icon(Icons.Outlined.Settings,null)},label={Text("设置")})
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).graphicsLayer {
                translationX = backProgress * 90.dp.toPx(); scaleX = 1 - backProgress * .04f; scaleY = scaleX
            }.verticalScroll(tabScrollStates[selectedTab]).padding(horizontal = 24.dp).widthIn(max=680.dp)) {
                Row(Modifier.fillMaxWidth().padding(top=12.dp,bottom=28.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text(when(selectedTab) { 1 -> "历史记录"; 2 -> "设置"; else -> "声屿" }, fontSize=22.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f))
                }
                if (selectedTab == 2) {
                    SettingsContent(themeMode=themeMode,onThemeChange={ mode ->
                        themeMode=mode
                        preferences.edit().putInt("theme_mode",mode).apply()
                    })
                } else if (page) {
                    Text("留住每一段声音",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.SemiBold)
                    Text("${state.history.size} 个音频 · 仅存于此设备",color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(top=8.dp,bottom=24.dp))
                    if(state.history.isEmpty()) Panel { Text("还没有音频",fontWeight=FontWeight.SemiBold); Text("选择视频，提取完成后会出现在这里。",modifier=Modifier.padding(top=8.dp),color=MaterialTheme.colorScheme.onSurfaceVariant) }
                    state.history.forEach { file ->
                        AudioFileCard(file, playing==file, { play(file) }, { save(file) }, { share(file) }, { deleteFile=file }, { stop(); transcriptionFile=file.absolutePath })
                        Spacer(Modifier.height(16.dp))
                    }
                } else {
                    Text("让声音，\n自由留下。", fontSize=36.sp,lineHeight=46.sp,fontWeight=FontWeight.SemiBold)
                    Text("从视频中提取音频，简单而安静。",color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(top=12.dp,bottom=28.dp))
                    Panel {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Icon(Icons.Outlined.GraphicEq,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(30.dp))
                            Text("视频 → 音频",fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(start=12.dp))
                        }
                        Waveform(Modifier.fillMaxWidth().height(76.dp).padding(vertical=18.dp))
                        Text(state.source?.name ?: "选择一个视频开始", maxLines=2,overflow=TextOverflow.Ellipsis,fontWeight=FontWeight.Medium)
                        Text(state.source?.let { "${duration(it.durationUs)} · ${it.sampleRate} Hz · ${it.channelCount} 声道" } ?: "使用系统文件选择器，不读取整个相册",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(top=8.dp,bottom=20.dp))
                        OutlinedButton(onClick={ picker.launch(arrayOf("video/*")) },enabled=!state.busy && !state.inspecting,modifier=Modifier.fillMaxWidth().heightIn(min=52.dp),shape=RoundedCornerShape(18.dp)) {
                            Icon(Icons.Outlined.Add,null); Spacer(Modifier.width(8.dp)); Text(if(state.inspecting) "正在读取…" else if(state.source==null) "选择视频" else "更换视频")
                        }
                    }
                    if (state.inspecting) TextButton(onClick=vm::cancel,modifier=Modifier.fillMaxWidth()) { Text("取消读取") }
                    state.failureMessage?.let { failure ->
                        Spacer(Modifier.height(18.dp))
                        Panel {
                            Text("处理未完成",color=MaterialTheme.colorScheme.error,fontWeight=FontWeight.SemiBold)
                            Text(failure,modifier=Modifier.padding(top=8.dp),style=MaterialTheme.typography.bodyMedium)
                            Text("可复制技术诊断协助定位。诊断不含文件名、路径、Key或媒体内容。",modifier=Modifier.padding(top=8.dp),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                            Row {
                                TextButton(onClick={
                                    runCatching { clipboard.setText(androidx.compose.ui.text.AnnotatedString(Diagnostics.copySummary())) }
                                        .onSuccess { vm.message("技术诊断已复制。") }.onFailure { vm.message("无法复制，请重试。") }
                                }) { Text("复制诊断信息") }
                                TextButton(onClick=vm::dismissFailure) { Text("关闭提示") }
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    if(state.source != null) Panel {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if(state.format==OutputFormat.M4A) "M4A 音频" else "WAV 音频",fontWeight=FontWeight.SemiBold)
                                Text(if(state.format==OutputFormat.WAV) "无压缩 PCM · 文件较大" else if(state.source!!.mime=="audio/mp4a-latm") "原始音轨 · 无损提取" else "系统编码 · AAC 高兼容",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(top=5.dp))
                            }
                            Icon(Icons.Outlined.CheckCircle,null,tint=MaterialTheme.colorScheme.primary)
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.padding(top=16.dp)) {
                            OutputFormat.entries.forEach { format -> FilterChip(selected=state.format==format,onClick={vm.format(format)},enabled=!state.busy,label={Text(format.name)}) }
                        }
                        if(state.busy) {
                            Spacer(Modifier.height(24.dp))
                            if(state.source!!.durationUs>0) LinearProgressIndicator(progress={ state.progress },modifier=Modifier.fillMaxWidth()) else LinearProgressIndicator(modifier=Modifier.fillMaxWidth())
                            Text(if(state.source!!.durationUs>0) "正在提取 ${(state.progress*100).toInt()}%" else "正在提取…",modifier=Modifier.padding(top=12.dp),style=MaterialTheme.typography.bodySmall)
                            Text("请保持应用打开；锁屏或退出可能中断处理。",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(top=6.dp))
                            TextButton(onClick=vm::cancel,modifier=Modifier.align(Alignment.End)) { Text("取消提取") }
                        } else {
                            Button(onClick={ stop(); vm.extract() },modifier=Modifier.fillMaxWidth().padding(top=22.dp).heightIn(min=54.dp),shape=RoundedCornerShape(18.dp)) { Text(if(state.result != null) "重新提取" else "开始提取") }
                        }
                    }
                    state.result?.let { file ->
                        Spacer(Modifier.height(22.dp)); Text("提取完成",fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(bottom=12.dp))
                        AudioFileCard(file, playing==file, { play(file) }, { save(file) }, { share(file) }, { deleteFile=file }, null)
                        TextButton(onClick={selectedTab=1},modifier=Modifier.fillMaxWidth()) { Text("查看历史记录") }
                    }
                    Row(Modifier.padding(top=26.dp,bottom=32.dp),verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Lock,null,modifier=Modifier.size(16.dp),tint=MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("本地提取 · 转写需联网并上传音频",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(start=8.dp))
                    }
                    Text("音频保存在应用内。重要文件请另存；卸载应用会删除音频库。",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(bottom=26.dp))
                }
            }
        }
        deleteFile?.let { file -> AlertDialog(onDismissRequest={deleteFile=null},title={Text("删除这个音频？")},text={Text("删除应用内音频及其转写文字、分段缓存；不影响已另存的文件。")},confirmButton={TextButton(onClick={if(playing==file)stop();vm.delete(file);deleteFile=null}){Text("删除")}},dismissButton={TextButton(onClick={deleteFile=null}){Text("取消")}}) }
    }
}
@Composable private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Surface(shape=RoundedCornerShape(26.dp),shadowElevation=2.dp,border=BorderStroke(.5.dp,MaterialTheme.colorScheme.outlineVariant),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp),content=content) }
}
@Composable private fun AudioFileCard(file: File,playing:Boolean,play:()->Unit,save:()->Unit,share:()->Unit,delete:()->Unit,transcribe:(()->Unit)?) {
    Panel {
        Row(verticalAlignment=Alignment.CenterVertically) {
            FilledTonalIconButton(onClick=play) { Icon(if(playing) Icons.Outlined.Stop else Icons.Outlined.PlayArrow,if(playing) "停止播放" else "播放音频") }
            Column(Modifier.weight(1f).padding(start=10.dp)) { Text(file.name,maxLines=2,overflow=TextOverflow.Ellipsis,fontWeight=FontWeight.Medium); Text(String.format(Locale.ROOT,"%s · %.2f MB",file.extension.uppercase(Locale.ROOT),file.length()/1048576.0),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        if (transcribe != null) FilledTonalButton(onClick=transcribe,modifier=Modifier.fillMaxWidth().padding(top=16.dp)) { Icon(Icons.Outlined.Notes,null,modifier=Modifier.size(18.dp)); Text(" 转为文字 · MiniMax") }
        Row(Modifier.fillMaxWidth().padding(top=12.dp),horizontalArrangement=Arrangement.SpaceBetween) {
            TextButton(onClick=save){Icon(Icons.Outlined.SaveAlt,null,modifier=Modifier.size(18.dp));Text(" 另存")}
            TextButton(onClick=share){Icon(Icons.Outlined.Share,null,modifier=Modifier.size(18.dp));Text(" 分享")}
            IconButton(onClick=delete){Icon(Icons.Outlined.DeleteOutline,"删除音频",tint=MaterialTheme.colorScheme.onSurfaceVariant)}
        }
    }
}
@Composable private fun Waveform(modifier:Modifier) {
    val color=MaterialTheme.colorScheme.primary
    Canvas(modifier) { val bars=42; for(i in 0 until bars) { val h=(.15f + .85f*kotlin.math.abs(kotlin.math.sin(i*.74f))*kotlin.math.sin((i+1f)/(bars+1)*Math.PI).toFloat())*size.height; val x=size.width*i/(bars-1); drawLine(color.copy(alpha=.35f+.55f*h/size.height),Offset(x,(size.height-h)/2),Offset(x,(size.height+h)/2),3.dp.toPx(),StrokeCap.Round) } }
}
private fun duration(us:Long):String { val sec=us/1_000_000; return "%d:%02d".format(sec/60,sec%60) }
