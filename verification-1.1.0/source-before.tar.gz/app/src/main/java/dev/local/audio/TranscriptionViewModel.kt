package dev.local.audio

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

data class TranscriptionUiState(
    val hasKey:Boolean=false,
    val busy:Boolean=false,
    val progress:Float?=null,
    val status:String="",
    val text:String="",
    val complete:Boolean=false,
    val hasPartial:Boolean=false,
    val message:String?=null,
)
class TranscriptionViewModel(app:Application):AndroidViewModel(app) {
    private val engine=TranscriptionEngine(app)
    private val keys=ApiKeyStore(app)
    private val mutable=MutableStateFlow(TranscriptionUiState())
    val state=mutable.asStateFlow()
    private var work:Job?=null
    fun load(file:File) {
        viewModelScope.launch {
            try {
                val hasKey=withContext(Dispatchers.IO){!keys.read().isNullOrBlank()}
                mutable.update{it.copy(hasKey=hasKey)}
                refresh(file)
            } catch(_:Exception) { message("无法读取本地转写设置，请重新配置 API Key。") }
        }
    }
    private suspend fun refresh(file:File) {
        val result=withContext(Dispatchers.IO){engine.cached(file)} ?: return
        mutable.update{it.copy(text=result.text,complete=result.complete,hasPartial=result.text.isNotBlank() && !result.complete)}
    }
    fun setKey(value:String) {
        if(mutable.value.busy)return
        viewModelScope.launch {
            try { withContext(Dispatchers.IO){keys.save(value)};mutable.update{it.copy(hasKey=true,message="API Key 已加密保存。")}}
            catch(_:Exception){message("无法安全保存 API Key，请检查设备锁屏和存储状态。")}
        }
    }
    fun deleteKey() {
        if(mutable.value.busy)return
        viewModelScope.launch {
            try{withContext(Dispatchers.IO){keys.clear()};mutable.update{it.copy(hasKey=false,message="已删除 API Key。")}}
            catch(_:Exception){message("无法删除 API Key，请重试。")}
        }
    }
    fun start(file:File) {
        if(mutable.value.busy)return
        mutable.update{it.copy(busy=true,status="准备音频…",progress=null,message=null)}
        work=viewModelScope.launch {
            try {
                val key=withContext(Dispatchers.IO){keys.read()} ?: error("请先配置 API Key。")
                val result=withContext(Dispatchers.IO){engine.transcribe(file,key){ progress ->
                    mutable.update{it.copy(status=progress.stage + if(progress.total>0) " · ${progress.completed}/${progress.total} 段完成" else "",progress=progress.uploadProgress)}
                }}
                mutable.update{it.copy(text=result.text,complete=result.complete,hasPartial=!result.complete,status=if(result.complete) "转写完成" else "有分段尚未完成",progress=1f)}
            } catch(_:CancellationException) {
                mutable.update{it.copy(status="已取消。成功分段已保留，可继续。")}
            } catch(e:Exception) {
                mutable.update{it.copy(status="转写未完成，可重试未完成分段。",message=e.localizedMessage ?: "转写失败，请检查网络和 API Key。")}
            } finally {
                withContext(NonCancellable) { runCatching{refresh(file)} }
                mutable.update{it.copy(busy=false,progress=null)}
            }
        }
    }
    fun cancel(){work?.cancel()}
    fun clearMessage(){mutable.update{it.copy(message=null)}}
    fun message(text:String){mutable.update{it.copy(message=text)}}
    fun saveText(uri:Uri) {
        val text=mutable.value.text
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openOutputStream(uri,"wt")?.bufferedWriter(Charsets.UTF_8)?.use{it.write(text)} ?: error("无法打开保存位置")
                }
                message("文字已保存。")
            }catch(_:Exception){message("保存失败，请重新选择位置。")}
        }
    }
}
