package dev.local.audio

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Content only: host owns scrolling, insets, navigation and durable theme preference. 0 system, 1 light, 2 dark. */
@Composable
fun SettingsContent(themeMode: Int, onThemeChange: (Int) -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var diagnosticStatus by remember { mutableStateOf<String?>(null) }
    var showKey by remember { mutableStateOf(false) }
    var keyStatus by remember { mutableStateOf("正在读取配置…") }
    LaunchedEffect(Unit) {
        keyStatus = withContext(Dispatchers.IO) {
            runCatching { if (ApiKeyStore(context).read().isNullOrBlank()) "尚未配置" else "已加密保存在此设备" }
                .getOrDefault("读取失败，可重新配置")
        }
    }
    Column(Modifier.fillMaxWidth()) {
        Text("按你的习惯使用声屿。", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp, bottom = 28.dp))
        Text("外观", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 12.dp))
        SettingsPanel {
            Column(Modifier.selectableGroup()) {
                listOf(0 to "跟随系统", 1 to "浅色", 2 to "深色").forEach { (mode, title) ->
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 54.dp).selectable(selected = themeMode == mode, role = Role.RadioButton, onClick = { onThemeChange(mode) }).padding(horizontal = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(title, modifier = Modifier.weight(1f))
                        RadioButton(selected = themeMode == mode, onClick = null)
                    }
                }
            }
        }
        Text("语音转文字", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 28.dp, bottom = 12.dp))
        SettingsPanel {
            Row(Modifier.fillMaxWidth().clickable(onClick = { showKey = true }).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Key, null, tint = MaterialTheme.colorScheme.primary)
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text("MiniMax API Key", fontWeight = FontWeight.Medium)
                    Text(keyStatus, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 5.dp))
                }
                Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, "打开 API Key 设置")
            }
        }
        Text("Key 只在此设备加密保存，可随时替换或删除。无需配置 Key，也能在主页离线提取音频。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
        Text("提取完成的文件位于历史记录。需要文字时，再打开该条目的“转文字”，确认后才会上传音频到 MiniMax。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 20.dp, bottom = 24.dp))
        Text("本地诊断", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 12.dp))
        SettingsPanel {
            Column(Modifier.padding(20.dp)) {
                Text("仅包含应用/系统版本、格式类型、处理阶段与采样数值。不含 API Key、文件名、URI、音视频内容或转写文字。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("诊断只保存在当前进程内存，不写入文件、不自动上传。点击复制后会进入系统剪贴板；由你决定是否分享。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp))
                OutlinedButton(onClick = {
                    diagnosticStatus = runCatching {
                        clipboard.setText(AnnotatedString(Diagnostics.copySummary()))
                        "诊断信息已复制，未发送或上传。"
                    }.getOrDefault("无法复制，请重试。")
                }, modifier = Modifier.fillMaxWidth().padding(top = 16.dp).heightIn(min = 48.dp)) {
                    Text("复制诊断信息")
                }
                TextButton(onClick = {
                    Diagnostics.clear()
                    diagnosticStatus = "已清除内存中的诊断。此前复制到剪贴板的内容不会被清除。"
                }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                    Text("清除诊断")
                }
                diagnosticStatus?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp).semantics { liveRegion = LiveRegionMode.Polite })
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
    if (showKey) ApiKeySettingsDialog(onDismiss = { showKey = false }, onKeyChanged = { configured -> keyStatus = if (configured) "已加密保存在此设备" else "尚未配置" })
}
@Composable
private fun SettingsPanel(content: @Composable () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), border = BorderStroke(.5.dp, MaterialTheme.colorScheme.outlineVariant), shadowElevation = 2.dp, content = content)
}
