package dev.local.audio

import android.content.Intent
import androidx.activity.compose.PredictiveBackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TranscriptionScreen(file: File, onBack: () -> Unit) {
    val vm: TranscriptionViewModel = viewModel(key = "transcription:${file.absolutePath}")
    val state by vm.state.collectAsStateWithLifecycle()
    var keyDialog by remember { mutableStateOf(false) }
    var configuredKey by remember { mutableStateOf<Boolean?>(null) }
    val hasKey = configuredKey ?: state.hasKey
    var consent by remember { mutableStateOf(false) }
    var leaveConfirm by remember { mutableStateOf(false) }
    val currentBusy by rememberUpdatedState(state.busy)
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event -> if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP && currentBusy) vm.cancel() }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    fun requestBack() { if(state.busy) leaveConfirm=true else onBack() }
    var backProgress by remember { mutableFloatStateOf(0f) }
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val snackbar = remember { SnackbarHostState() }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri -> if(uri != null) vm.saveText(uri) }
    LaunchedEffect(file.absolutePath) {
        vm.load(file)
        configuredKey = withContext(Dispatchers.IO) { runCatching { !ApiKeyStore(context).read().isNullOrBlank() }.getOrDefault(false) }
    }
    LaunchedEffect(state.message) { state.message?.let { snackbar.showSnackbar(it); vm.clearMessage() } }
    PredictiveBackHandler { events ->
        try { events.collect { backProgress=it.progress }; requestBack() }
        catch (_:CancellationException) { }
        finally { backProgress=0f }
    }
    Scaffold(snackbarHost={SnackbarHost(snackbar)},containerColor=MaterialTheme.colorScheme.background) { insets ->
        Column(Modifier.fillMaxSize().padding(insets).graphicsLayer { translationX=backProgress*90.dp.toPx();scaleX=1-backProgress*.04f;scaleY=scaleX }.verticalScroll(rememberScrollState()).padding(horizontal=24.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=::requestBack){Icon(Icons.AutoMirrored.Outlined.ArrowBack,"返回")}
                Text("音频转文字",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f))
                IconButton(enabled=!state.busy,onClick={keyDialog=true}){Icon(Icons.Outlined.Key,"API Key 设置")}
            }
            Text("把声音，\n变成文字。",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=16.dp,bottom=12.dp))
            Text(file.name,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(bottom=24.dp))
            TranscriptPanel {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Outlined.CloudUpload,null,tint=MaterialTheme.colorScheme.primary)
                    Text("MiniMax 语音识别",fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(start=10.dp))
                }
                Text("转写会将音频发送至 MiniMax，可能产生 API 费用。视频不会上传。长音频会自动分段并按顺序拼接。",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(top=14.dp))
                Text(if(hasKey) "API Key 已加密保存在此设备" else "请先配置你的 MiniMax API Key",style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(top=14.dp))
                if(state.busy) {
                    Spacer(Modifier.height(22.dp))
                    if(state.progress != null) LinearProgressIndicator(progress={state.progress ?: 0f},modifier=Modifier.fillMaxWidth()) else LinearProgressIndicator(modifier=Modifier.fillMaxWidth())
                    Text(state.status,modifier=Modifier.padding(top=12.dp),style=MaterialTheme.typography.bodyMedium)
                    Text("请保持应用打开；切到后台会取消。成功分段会保留，重试无需全部重传。",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(top=8.dp))
                    TextButton(onClick=vm::cancel,modifier=Modifier.align(Alignment.End)){Text("取消")}
                } else {
                    if(state.status.isNotBlank()) Text(state.status,modifier=Modifier.padding(top=16.dp),style=MaterialTheme.typography.bodySmall)
                    Button(onClick={if(!hasKey){keyDialog=true}else consent=true},modifier=Modifier.fillMaxWidth().padding(top=20.dp).heightIn(min=52.dp),shape=RoundedCornerShape(18.dp)) {
                        Text(if(!hasKey) "配置 API Key" else if(state.hasPartial) "继续 / 重试未完成分段" else if(state.text.isNotBlank()) "重新检查转写结果" else "开始转写")
                    }
                }
            }
            if(state.text.isNotBlank()) {
                Spacer(Modifier.height(26.dp))
                Text(if(state.complete) "转写全文" else "已完成部分",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    TextButton(onClick={clipboard.setText(AnnotatedString(state.text));vm.message("已复制文字。")}) { Icon(Icons.Outlined.ContentCopy,null,modifier=Modifier.size(18.dp));Text(" 复制") }
                    TextButton(onClick={save.launch(file.nameWithoutExtension+".txt")}) { Icon(Icons.Outlined.SaveAlt,null,modifier=Modifier.size(18.dp));Text(" 另存") }
                    TextButton(onClick={runCatching { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {type="text/plain";putExtra(Intent.EXTRA_TEXT,state.text)},"分享转写文字")) }.onFailure {vm.message("没有可用的分享应用。")}}) { Icon(Icons.Outlined.Share,null,modifier=Modifier.size(18.dp));Text(" 分享") }
                }
                TranscriptPanel { SelectionContainer { Text(state.text,style=MaterialTheme.typography.bodyLarge) } }
            }
            Text("识别结果可能有误，请核对重要内容。删除 API Key 不会删除已生成的文字。",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(vertical=28.dp))
        }
    }
    if(leaveConfirm) AlertDialog(onDismissRequest={leaveConfirm=false},title={Text("取消转写并返回？")},text={Text("当前处理将取消，已成功的分段会保留。已上传内容可能仍在 MiniMax 处理并计费；下次可继续未完成分段。")},confirmButton={TextButton(onClick={leaveConfirm=false;vm.cancel();onBack()}){Text("取消并返回")}},dismissButton={TextButton(onClick={leaveConfirm=false}){Text("继续转写")}})
    if(consent) AlertDialog(onDismissRequest={consent=false},title={Text("上传音频到 MiniMax？")},text={Text("将上传“${file.name}”的音频内容到 api.minimaxi.com 进行识别。请确认有权处理该音频；敏感内容请谨慎上传。可能产生 API 费用。取消无法撤回已上传的内容或保证免除费用。")},confirmButton={TextButton(onClick={consent=false;vm.start(file)}){Text("同意并开始")}},dismissButton={TextButton(onClick={consent=false}){Text("取消")}})
    if(keyDialog) ApiKeySettingsDialog(onDismiss={keyDialog=false},onKeyChanged={configuredKey=it})
}
@Composable private fun TranscriptPanel(content:@Composable ColumnScope.()->Unit) {
    Surface(shape=RoundedCornerShape(26.dp),border=BorderStroke(.5.dp,MaterialTheme.colorScheme.outlineVariant),shadowElevation=2.dp,modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp),content=content) }
}
