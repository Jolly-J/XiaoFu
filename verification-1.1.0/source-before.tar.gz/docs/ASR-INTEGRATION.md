# MiniMax ASR 集成边界

核对日期：2026-10-25。

官方来源：
- https://solutions.minimaxi.com/debug/asr （国内调试页 api.minimaxi.com）
- https://platform.minimax.cn/docs/api-reference/speech-to-text （当前文档 api.minimax.cn）

使用官方调试页固定 HTTPS 端点 `https://api.minimaxi.com/v1/speech_to_text`，不接受用户自定义服务器、不跟随重定向。multipart 字段：model=asr-1.0、response_format=verbose_json、timestamp_level=word、stream=false。Authorization Bearer 只发给该主机。响应 `segments[].start/end` 以秒计。

官方限制 500 秒、50 MB；应用先在本地生成 PCM16 WAV，按不超过450秒和45,000,000字节双上限切片，每个接缝重叠1秒。字/词按全局时间戳中点归属到互不重叠的核心区间，按顺序合并。英文相邻词补空格，中文字符直接相连。不同分片的模型识别可能不同，接缝仍需人工校对；不承诺自动转写逐字无误。服务若没有返回时间戳则保留完整分段文本并提示可能重复，不擅自删词。

逐段成功响应在私有 noBackupFilesDir 按音频 SHA256 保存；失败停止，重新点击仅请求尚未完成段。可随时复制已完成部分。已完成全文再次打开直接读取，不重复付费请求。HTTP上传字节进度是真实发送进度；识别阶段显示等待结果，不伪造服务处理百分比。取消会断开连接，但已发送请求仍可能由服务处理或计费。

API Key 由用户在App填写，用Android Keystore AES-GCM加密后存在noBackupFilesDir，不写日志、不硬编码、不包含在导出文件。音频提取不联网；只有用户确认转写才上传所选音频分片。服务费用、保留策略由用户的MiniMax账户与服务条款决定。

实现限制：系统解码器须支持输入音轨；临时完整WAV需要额外磁盘，标准RIFF限制约4GB，超长音频可能需先在外部裁短。原始音频不修改。默认仅单/双声道，媒体兼容性依设备。真实MiniMax识别未测试（没有用户API Key）；本地模拟HTTP测试不能证明服务账户权限、额度、实际识别质量或地域连通性。
