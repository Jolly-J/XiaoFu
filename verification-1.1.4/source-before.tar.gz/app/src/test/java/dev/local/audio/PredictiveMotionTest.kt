package dev.local.audio

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs

class PredictiveMotionTest {
    @Test fun idleIsExactlyFullScreen() {
        assertEquals(BackCardGeometry(1f, 0f, 0f), backCardGeometry(1080f, 2400f, 3f, 0f, 1f, 600f))
    }
    @Test fun bothEdgesKeepEightDpGapAndNeverEscapeVertically() {
        for (progress in listOf(.1f, .25f, .5f, 1f)) for (direction in listOf(-1f, 1f)) {
            val g = backCardGeometry(1080f, 2400f, 3f, progress, direction, 10000f)
            val nearestHorizontalGap = 1080f * (1 - g.scale) / 2 - abs(g.x)
            val nearestVerticalGap = 2400f * (1 - g.scale) / 2 - abs(g.y)
            assertTrue(nearestHorizontalGap >= 24f * progress - .001f)
            assertTrue(nearestVerticalGap >= 24f * progress - .001f)
            assertTrue(g.scale >= .9f)
        }
    }
    @Test fun mirroredEdgesAndVerticalDirection() {
        val left = backCardGeometry(1080f, 2400f, 3f, .6f, 1f, 400f)
        val right = backCardGeometry(1080f, 2400f, 3f, .6f, -1f, -400f)
        assertEquals(left.scale, right.scale, 0f)
        assertEquals(-left.x, right.x, .001f)
        assertEquals(-left.y, right.y, .001f)
        assertTrue(left.y > 0)
    }
    @Test fun invalidProgressDoesNotOverscale() {
        assertEquals(1f, backCardGeometry(30f, 40f, 3f, -1f, 1f, 1f).scale, 0f)
        val g = backCardGeometry(30f, 40f, 3f, 2f, 1f, 1f)
        assertEquals(.9f, g.scale, .001f)
        assertEquals(0f, g.x, 0f)
    }
}
