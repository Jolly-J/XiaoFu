package dev.local.audio

import kotlin.math.abs
import kotlin.math.sign

/** Geometry in pixels. Independent of the UI/lifecycle so edge limits can be verified. */
internal data class BackCardGeometry(val scale: Float, val x: Float, val y: Float)
internal fun backCardGeometry(width: Float, height: Float, density: Float, progress: Float, direction: Float, verticalDrag: Float): BackCardGeometry {
    val p = progress.coerceIn(0f, 1f)
    val scale = 1f - .10f * p
    val horizontalRoom = (width * .05f - 8f * density).coerceAtLeast(0f) * p
    val verticalRoom = (height * .05f - 8f * density).coerceAtLeast(0f) * p
    val normalizedDrag = (abs(verticalDrag) / height.coerceAtLeast(1f)).coerceIn(0f, 1f)
    val easedDrag = 1f - (1f - normalizedDrag) * (1f - normalizedDrag)
    return BackCardGeometry(scale, horizontalRoom * direction.coerceIn(-1f, 1f), verticalRoom * easedDrag * sign(verticalDrag))
}
