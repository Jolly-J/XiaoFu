package dev.local.audio

import androidx.activity.compose.PredictiveBackHandler
import androidx.activity.BackEventCompat
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.clearAndSetSemantics
import kotlin.math.max

/** Grouped tool panels: visible thin boundary, restrained fill, no blanket drop shadow. */
@Composable
internal fun SoftSurface(modifier: Modifier = Modifier, accent: Color? = null, content: @Composable () -> Unit) {
    Surface(modifier = modifier, shape = RoundedCornerShape(28.dp), color = accent?.copy(alpha = .035f)?.compositeOver(MaterialTheme.colorScheme.surface) ?: MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, accent?.copy(alpha = .25f)?.compositeOver(MaterialTheme.colorScheme.surface) ?: MaterialTheme.colorScheme.outlineVariant), content = content)
}

@Composable
internal fun RoundIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, enabled: Boolean = true, onClick: () -> Unit) {
    Surface(shape = androidx.compose.foundation.shape.CircleShape, color = MaterialTheme.colorScheme.surface, shadowElevation = 1.dp) {
        IconButton(onClick = onClick, enabled = enabled) { Icon(icon, description) }
    }
}

@Composable
internal fun AccentIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, size: Dp = 36.dp, iconSize: Dp = 23.dp) {
    Surface(shape = RoundedCornerShape(size * .3f), color = color.copy(alpha = .12f), modifier = Modifier.size(size)) {
        Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = color, modifier = Modifier.size(iconSize)) }
    }
}

/**
 * One owner for gesture preview, cancellation and committed/button transitions.
 * Uses public predictive-back progress, with the floating-card mechanics documented by
 * Flutter's PredictiveBackPageTransitionsBuilder / Android predictive-back motion specs.
 * The actual previous page stays composed underneath. Root has no callback.
 */
private enum class BackPhase { Rest, Entering, Dragging, Returning, Leaving }

@Composable
internal fun PredictivePage(
    onBack: () -> Unit,
    visible: Boolean = true,
    enabled: Boolean = true,
    content: @Composable () -> Unit,
) {
    var present by remember { mutableStateOf(visible) }
    var phase by remember { mutableStateOf(BackPhase.Rest) }
    val preview = remember { Animatable(0f) }
    val departure = remember { Animatable(0f) }
    val arrival = remember { Animatable(1f) }
    var direction by remember { mutableFloatStateOf(1f) }
    var verticalDrag by remember { mutableFloatStateOf(0f) }
    val currentBack by rememberUpdatedState(onBack)
    val currentVisible by rememberUpdatedState(visible)
    val gestureEasing = remember { CubicBezierEasing(0f, 0f, 0f, 1f) }
    val finishEasing = remember { CubicBezierEasing(.1f, .1f, 0f, 1f) }
    val density = LocalDensity.current.density

    suspend fun leave(notify: Boolean) {
        if (!present || phase == BackPhase.Leaving) return
        phase = BackPhase.Leaving
        arrival.snapTo(1f)
        departure.snapTo(0f)
        departure.animateTo(1f, tween(durationMillis = 400, easing = finishEasing))
        // Remove only after the outgoing surface is fully transparent. No second exit animation.
        present = false
        if (notify) currentBack()
        preview.snapTo(0f)
        departure.snapTo(0f)
        verticalDrag = 0f
        phase = BackPhase.Rest
    }

    LaunchedEffect(visible) {
        if (visible && !present) {
            preview.snapTo(0f); departure.snapTo(0f); arrival.snapTo(0f)
            verticalDrag = 0f; direction = 1f
            present = true; phase = BackPhase.Entering
            arrival.animateTo(1f, tween(220, easing = finishEasing))
            phase = BackPhase.Rest
        } else if (!visible && present) {
            leave(notify = false)
        }
    }

    PredictiveBackHandler(enabled = enabled && present && visible) { events ->
        // Keep rapid repeated Back from falling through to the underlying route/root.
        if (phase == BackPhase.Leaving || phase == BackPhase.Entering) {
            events.collect { }
        } else {
            var startY: Float? = null
            var receivedGesture = false
            try {
                phase = BackPhase.Dragging
                events.collect { event ->
                    if (phase == BackPhase.Dragging) {
                        receivedGesture = true
                        if (startY == null) startY = event.touchY
                        verticalDrag = event.touchY - (startY ?: event.touchY)
                        direction = if (event.swipeEdge == BackEventCompat.EDGE_LEFT) 1f else -1f
                        preview.snapTo(gestureEasing.transform(event.progress.coerceIn(0f, 1f)))
                    }
                }
                if (!receivedGesture) direction = 1f // Three-button/keyboard Back uses the same finish.
                leave(notify = true)
            } catch (cancelled: CancellationException) {
                // A destroyed composition must not be revived by an animation.
                if (!currentCoroutineContext().isActive) throw cancelled
                if (currentVisible && present && phase != BackPhase.Leaving) {
                    phase = BackPhase.Returning
                    preview.animateTo(0f, spring(dampingRatio = .9f, stiffness = 600f))
                    verticalDrag = 0f
                    phase = BackPhase.Rest
                }
            }
        }
    }
    if (!present) return
    val hidingSemantics = if (!enabled || !visible) Modifier.clearAndSetSemantics { } else Modifier
    Surface(modifier = Modifier.fillMaxSize().then(hidingSemantics).graphicsLayer {
        val geometry = backCardGeometry(size.width, size.height, density, preview.value, direction, verticalDrag)
        val finish = departure.value
        val enter = arrival.value
        scaleX = (geometry.scale + (1f - geometry.scale) * finish) * (.97f + .03f * enter)
        scaleY = scaleX
        translationX = geometry.x * (1f - finish) + direction * size.height * .10f * finish + size.width * .035f * (1f - enter)
        translationY = geometry.y * (1f - finish)
        alpha = (1f - finish) * enter
        val rounding = max(preview.value.coerceIn(0f, 1f) * (1f - finish), 1f - enter)
        shape = RoundedCornerShape((32f * rounding).dp)
        clip = true
        shadowElevation = 8.dp.toPx() * rounding
    }.pointerInput(phase) {
        if (phase != BackPhase.Rest) awaitPointerEventScope {
            while (true) awaitPointerEvent(PointerEventPass.Initial).changes.forEach { it.consume() }
        }
    }, color = MaterialTheme.colorScheme.background) { content() }
}
